﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace prodcat.Migrations
{
    public partial class DMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
