using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace prodcat.Models
{

        public class Association
        {
            [Key]
            public int AssocationId {get;set;}
            public int ProductId {get;set;}
            public int CategoryId {get;set;}
            public Category Category { get; set; }
            public Product Product { get; set; }
            
        }
}