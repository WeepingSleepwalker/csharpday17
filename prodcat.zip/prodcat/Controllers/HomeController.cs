using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.Linq;
using prodcat.Models;

namespace prodcat.Controllers     
{
    public class HomeController : Controller   
    {
        private MyContext dbContext;
 
        public HomeController(MyContext context)
        {
            dbContext = context;
        }
     
        [HttpGet]     
        [Route("")]     
        public IActionResult Index()
        {

            return Redirect("Category");
        
        }
        [HttpGet]     
        [Route("Category")]     
        public IActionResult Category()
        {
             ViewBag.AllCats = dbContext.Categorys.OrderByDescending(c => c.Name).ToList();
   
            return View();
        
        }

        [HttpPost]
        [Route("CreateCategory")]
        public IActionResult CreateCategory(Category NewCat)
        {
            
            dbContext.Add(NewCat);
            dbContext.SaveChanges();

            return Redirect("Category");
        }
        [HttpGet]     
        [Route("Product")]     
        public IActionResult Product()
        {
             ViewBag.AllProds = dbContext.Products.OrderByDescending(c => c.Name).ToList();
   
            return View();
        
        }

        [HttpPost]
        [Route("CreateProduct")]
        public IActionResult CreateProduct(Product NewProd)
        {
   
            dbContext.Add(NewProd);
            dbContext.SaveChanges();

            return Redirect("Product");
        }

        [HttpGet]     
        [Route("Category/{categoryId}")]     
        public IActionResult CategoryCon(int categoryId)
        {
             ViewBag.ThisCat = dbContext.Categorys.FirstOrDefault(u => u.CategoryId == categoryId);
             ViewBag.AllProds = dbContext.Products
             .Include(p=>p.CategoryWithin)
             .ThenInclude(d=>d.Category)
             .Where(e=>!e.CategoryWithin
             .Any(f=>f.CategoryId==categoryId))
             .ToList();
             ViewBag.CatswAssandProd = dbContext.Categorys
    	        .Include(p => p.ProductsInside)
                .ThenInclude(sub => sub.Product)
                .FirstOrDefault(person => person.CategoryId == categoryId);
            return View();
        
        }

        [HttpPost]
        [Route("AddProduct/{atId}")]
        public IActionResult AddProduct(int atId, Association newCat)
        {
            newCat.CategoryId = atId;
            dbContext.Add(newCat);
            dbContext.SaveChanges();

            return Redirect($"/Category/{atId}");
        }
        [HttpGet]     
        [Route("Product/{ProductId}")]     
        public IActionResult ProductCon(int productId)
        {
             ViewBag.ThisProd = dbContext.Products.FirstOrDefault(u => u.ProductId == productId);
             ViewBag.AllCats = dbContext.Categorys
             .Include(p=>p.ProductsInside)
             .ThenInclude(d=>d.Product)
             .Where(e=>!e.ProductsInside
             .Any(f=>f.ProductId==productId))
             .ToList();
             ViewBag.ProdwAssandCat = dbContext.Products
    	        .Include(p => p.CategoryWithin)
                .ThenInclude(sub => sub.Category)
                .FirstOrDefault(person => person.ProductId == productId);
            return View();
        
        }

        [HttpPost]
        [Route("AddCategory/{atId}")]
        public IActionResult AddCategory(int atId, Association newProd)
        {
            newProd.ProductId = atId;
            dbContext.Add(newProd);
            dbContext.SaveChanges();

            return Redirect($"/Product/{atId}");
        }
    }
}